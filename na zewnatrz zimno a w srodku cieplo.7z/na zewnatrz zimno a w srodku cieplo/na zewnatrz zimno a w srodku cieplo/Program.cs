﻿using System;

namespace na_zewnatrz_zimno_a_w_srodku_cieplo
{
    class Program
    {
        static void Main(string[] args)
        {
            Kebab k1 = new MegaKebab();
            Console.WriteLine(k1.GetOpis() + " kosztuje: " + $"{k1.Koszt()}");
            k1 = new MiesoDrobiowe(k1);
            Console.WriteLine(k1.GetOpis() + " kosztuje: " + $"{k1.Koszt()}");
            k1 = new SosCzosnkowy(k1);
            Console.WriteLine(k1.GetOpis() + " kosztuje: " + $"{k1.Koszt()}");
            k1 = new Cebula(k1);
            Console.WriteLine(k1.GetOpis() + " kosztuje: " + $"{k1.Koszt()}");
            k1 = new SerFeta(k1);
            Console.WriteLine(k1.GetOpis() + " kosztuje: " + $"{k1.Koszt()}");
        }
    }
    public abstract class Kebab
    {
        public abstract double Koszt();
        public abstract string GetOpis();
    }
    public class MalyKebab : Kebab
    {

        public override double Koszt()
        {
            return 9.00;
        }
        public override string GetOpis()
        {
            return "Mały Kebab";
        }

    }
    public class MegaKebab : Kebab
    {

        public override double Koszt()
        {
            return 15.00;
        }
        public override string GetOpis()
        {
            return "Mega Kebab";
        }

    }
    public class GigaKebab : Kebab
    {

        public override double Koszt()
        {
            return 21.00;
        }
        public override string GetOpis()
        {
            return "Giga Kebab";
        }

    }
    public abstract class KebabDekorator : Kebab
    {
        protected Kebab kebs;
        public KebabDekorator(Kebab _kebs)
        {
            kebs = _kebs;
        }

        public override string GetOpis()
        {
            return kebs.GetOpis();
        }
        public override double Koszt()
        {
            return kebs.Koszt();
        }
    }
    public class BulkaCienka : KebabDekorator
    {
        public BulkaCienka(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.0 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Bułka Cienka";
        }


    }
    public class BulkaGruba : KebabDekorator
    {
        public BulkaGruba(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 1.0 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Bułka Gruba";
        }


    }
    public class MiesoWolowe : KebabDekorator
    {
        public MiesoWolowe(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 1.0 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Mieso Wołowe";
        }


    }
    public class MiesoDrobiowe : KebabDekorator
    {
        public MiesoDrobiowe(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.5 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Mieso Drobiowe";
        }

    }
    public class MiesoMieszane : KebabDekorator
    {
        public MiesoMieszane(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.8 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Mieso Mieszane";
        }

    }
    public class Oliwki : KebabDekorator
    {
        public Oliwki(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.4 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Oliwki";
        }

    }
    public class SerFeta : KebabDekorator
    {
        public SerFeta(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.3 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Ser Feta";
        }

    }
    public class Cebula : KebabDekorator
    {
        public Cebula(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.1 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Cebula";
        }

    }
    public class SosCzosnkowy : KebabDekorator
    {
        public SosCzosnkowy(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.5 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Sos Czosnkowy";
        }

    }
    public class SosMeksykanski : KebabDekorator
    {
        public SosMeksykanski(Kebab _kebs) : base(_kebs)
        {

        }
        public override double Koszt()
        {
            return 0.5 + kebs.Koszt();
        }
        public override string GetOpis()
        {
            return kebs.GetOpis() + ", Sos Meksykanski";
        }

    }

}

