﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cwiczenia5
{
    interface IRideable
    {
        void Ride();
    }

     
    interface IGitarzysta
    {
        void Graj();
    }
    interface ISkrzypek
    {
        void Graj();
    }

    interface IClonable
    {

    }

   
}
