﻿using System;

namespace cwiczenia5
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car();
            car1.Ride();
            Bicycle bicycle1 = new Bicycle();
            bicycle1.Ride();
            Osoba osoba1 = new Osoba();
            osoba1.Graj();
            IGitarzysta g1 = new Osoba();
            g1.Graj();
            ISkrzypek s1 = new Osoba();
            s1.Graj();
            Test t1 = new Test(255);
            //t1.poleTestowe.slowo = "slowo";
            Test t2 = new Test(0);
            t2 = t1;
            Test t3 = new Test(0);
            t3 = t1.GlebokaKopia();
            t1.liczba = 347;
           //t1.poleTestowe.slowo = "kaczka";
            t1.Wypisz();
            t2.Wypisz();
            t3.Wypisz();


        }
    }
    class Vehicle
    {

    }
    class Car : Vehicle, IRideable
    {
        public void Ride()
        {
            Console.WriteLine("Jade samochodem");
        }
    }

    class Bicycle : Vehicle, IRideable
    {
        public void Ride()
        {
            Console.WriteLine("Jade rowerem");
        }
    }

    class Osoba : ISkrzypek, IGitarzysta
    {
        public void Graj()
        {
            Console.WriteLine("Gram ale nie wiem na czym");
        }
        void IGitarzysta.Graj()
        {
            Console.WriteLine("Gram na gitarze");
        }
        void ISkrzypek.Graj()
        {
            Console.WriteLine("Gram na skrzypcach");

        }
    }
    
    class Test : IClonable
    {
        public int liczba;
        public Test2 poleTestowe;

        public Test(int liczba)
        {
            this.liczba = liczba;
        }

        public Test(int liczba, Test2 poleTestowe) : this(liczba)
        {
            this.poleTestowe = poleTestowe;
        }

        public object Clone()
        {
            return MemberwiseClone();
        }
        public void Wypisz()
        {
            Console.WriteLine("{0} {1}",liczba,poleTestowe.slowo);
        }
        public Test GlebokaKopia()
        {
            Test tempTest = new Test
            {
                liczba = this.liczba
            };
            tempTest.poleTestowe.słowo = this.poleTestowe.słowo;
            return tempTest;
        }

    }

    class Test2
    {
        public string slowo;
    }
}
